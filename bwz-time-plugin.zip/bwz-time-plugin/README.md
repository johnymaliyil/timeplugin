# bwz-time-plugin

SAP Build Work Zone (standard edition) shell plugin that shows the current time
and time zone in a popup after login.

## Prerequisites in the target subaccount

- Subscription to **SAP Build Work Zone, standard edition** (with a site created)
- Entitlements for these services (all consumed by the MTA, created on deploy):
  - `html5-apps-repo` / plan `app-host`
  - `destination` / plan `lite`
  - `xsuaa` / plan `application`
- **No Cloud Foundry runtime quota is needed** — the MTA deploys only content,
  no apps are pushed.

Local tools: Node.js + npm, `mbt` (`npm i -g mbt`), `cf` CLI v8 with the
MultiApps plugin (`cf install-plugin multiapps`).

## Deploy

```sh
cf login -a <your CF API endpoint>   # target the desired org/space
mbt build
cf deploy mta_archives/bwz-time-plugin_1.0.2.mtar
```

## Activate in Work Zone

1. Site Manager → **Channel Manager** → refresh the **HTML5 Apps** provider.
2. **Content Manager → Content Explorer** → HTML5 Apps → add **Time Popup Plugin**
   (it appears with type *Shell Plugin*; business solution
   `com.nttdata.bwztimeplugin.service`).
3. Assign it to a role (e.g. **Everyone**, or a custom role). For a custom role,
   also assign the role to the site (Site Settings → Assignments) and assign the
   generated role collection to the users in the BTP cockpit.
4. Hard-reload the site — the popup appears after the shell loads.

## Gotchas (learned the hard way)

- In `xs-app.json` the route must use `"service": "html5-apps-repo-rt"`.
  `html5-apps-repo-rs` is invalid and produces 500s on every file.
- `sap.cloud.service` (manifest.json) must differ from the normalized app id and
  must match the `sap.cloud.service` property of both destinations in `mta.yaml`.
- After changing already-deployed content, bump `applicationVersion` in
  `manifest.json` — Work Zone caches per version.
